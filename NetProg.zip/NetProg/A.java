import java.io.*;
import java.io.File;

public class A {
    public static void main(String [] args) {

        // The name of the file to open.
        String fileName = "A.txt";
        String fileName2 = "B.BIN";
        String fileName3 = "C.txt";
        
        try {
            // Assume default encoding.
            FileWriter fileWriter =
                new FileWriter(fileName);

            // Always wrap FileWriter in BufferedWriter.
            BufferedWriter bufferedWriter =
                new BufferedWriter(fileWriter);

            // Note that write() does not automatically
            // append a newline character.
            bufferedWriter.write("A1B2C3D4E5");
           
            // Always close files.
            bufferedWriter.close();
           
         //QUESTION 2
         
        
			FileReader fread = new FileReader(fileName);
			BufferedReader bread = new BufferedReader(fread);
			StringBuffer sbuff = new StringBuffer();
			String a;
			String b; //b is the string read from A.txt//
			String conv; //conv is the string in reverse order//
			
			while((a=bread.readLine()) != null)
			{
				sbuff.append(a);
				sbuff.append("\n");
			}
		
			fread.close();
			b = sbuff.toString();
			
			byte[] sbyte = b.getBytes();
			byte[] result = new byte[sbyte.length];
			
			for(int i=0; i<sbyte.length; i++)
			{
				result[i] = sbyte[sbyte.length-i-1];
			}
			
			conv = new String(result);
			
			FileWriter fwriter = new FileWriter(fileName2);
			BufferedWriter bwriter = new BufferedWriter(fwriter);
			
			//P/S: note that write() doesn't automatically append a newline character//
			bwriter.write(conv);
			
			bwriter.close();
			System.out.println(conv);
			
			
			//QUESTION 3
			
           // reading the data//
            byte[] buff = new byte[1000];

            FileInputStream isfile = new FileInputStream("B.BIN");

            int total = 0;
            int nRead = 0;
			
            while((nRead = isfile.read(buff)) != -1)
			{
                // Convert to String so we can display it. Of course you wouldn't want to do this with a 'real' binary file.
                System.out.println(new String(buff));
                total += nRead;
            }   

            // Always close files.
            isfile.close();        

			FileWriter fwriter1 = new FileWriter(fileName3);
			BufferedWriter bwriter1 = new BufferedWriter(fwriter1);
			
			//P/S: note that write() doesn't automatically append a newline character//
			bwriter1.write(new String(buff));
			
			bwriter1.close();
            System.out.println("Read " + total + " bytes");
           
     
        }
        catch(IOException ex) {
            System.out.println(
                "Error writing to file '"
                + fileName + "'");
            // Or we could just do this:
            // ex.printStackTrace();
        }
    }
}
